# spec-review-002 Round 1 / Round 2 同一モデル比較（16レビュー版）

## 1. 比較条件

- Round 1とRound 2でモデル名・モードが一致する比較対象は5組。
- Review targetとGold Findingは同一。
- Round 2はポータブルEvidence版v2プロンプトを使用。
- 各モデル1回ずつのため、差分をプロンプト効果だけに帰属できない。
- 追加されたLuna XHighとClaude Sonnet 5 HighにはRound 1の同一条件サンプルがないため、Round間点数比較には加えない。
- Claude Sonnet 5 HighはRound 2内に2実行あるため、別途再現性を比較する。

## 2. 点数比較

| モデル | Round 1 | Round 2 | 差分 | R1 Verdict | R2 Verdict |
|---|---:|---:|---:|---|---|
| Kimi K3 | 80 | 76 | **-4** | PASS WITH FINDINGS / READY | FAIL / NOT READY |
| Composer 2.5 Fast | 78 | 73 | **-5** | FAIL / NOT READY | PASS WITH FINDINGS / READY |
| Gork 4.5 High Fast | 76 | 88 | **+12** | FAIL / NOT READY | FAIL / NOT READY |
| GLM 5.2 High | 66 | 62 | **-4** | PASS WITH FINDINGS / READY | PASS WITH FINDINGS / READY |
| DeepSeek V4 Pro | 46 | 56 | **+10** | PASS WITH FINDINGS / READY | PASS WITH FINDINGS / READY |

- 5モデル平均: Round 1 **69.2** → Round 2 **71.0**（+1.8）。
- 正しいVerdict数はRound 1、Round 2ともに2 / 5で変化なし。
- 追加2モデルはRound 1対応データがないため、この平均には含めない。

## 3. モデル別変化

### Kimi K3

重大度・Verdictは改善。Round 1で拾ったF-001/F-004/F-005を失い、Round 2はF-002中心へ狭くなった。

### Composer 2.5 Fast

冪等性・監査・code観点は増えたが、Round 1のF-001を見逃し、MajorをMinor扱いしてVerdictが悪化。

### Gork 4.5 High Fast

F-003を中核Majorとして認識し、F-006/F-009も追加。F-004と正しいFAILを維持し、最も明確に改善。

### GLM 5.2 High

F-003/F-009の一部を新規検出した一方、Round 1のF-005/F-007を失った。主要見逃しと甘いReady判定は継続。

### DeepSeek V4 Pro

B-01と逆方向の修正案が消えPrecisionは改善。ただしRound 2はF-002の一部だけで、RecallとVerdictは依然不十分。

## 4. Round 2内の同一モデル再現性

### Claude Sonnet 5 High

| 実行 | 点数 | Verdict | Gold coverage |
|---|---:|---|---|
| 通常実行 | 58 | PASS WITH FINDINGS / READY | F-002 partialのみ |
| browser実行 | 77 | FAIL / NOT READY | F-002 partial、F-005 full、F-009 full |

差分:

- 点数: **+19**
- Verdict: `READY` → `NOT READY`
- browser実行は正しいFAILへ改善
- ただし両実行ともF-001、F-003、F-004を見逃した
- 共通Findingより、実行ごとに異なる周辺Findingを検出した

この差をbrowser利用の効果だけに帰属することはできない。サンプリング、コンテキストの読み取り順、ツール使用、モデル実装差などが混在する。少なくとも、同一モデル単発レビューを確定判定に使用することは危険である。

## 5. プロンプト改訂の効果

### 改善が見られた点

- Gorkは冪等性を中核Majorとして認定し、製品範囲・監査・未決事項まで広げた。
- KimiはRequired fixesとReady判定の矛盾を解消した。
- DeepSeek ProはB-01と逆方向の危険な修正案を出さなくなった。
- 多くのモデルがEvidence完全性、正本順位、外部アクセス禁止を明示的に守った。

### 改善しなかった点

- 同一モデル5組の正しいVerdict数は増えていない。
- F-001の「解約後は2種類のみ許可」は、同一5モデル全てがRound 2でも見逃した。
- Composer、GLM、DeepSeek ProはMajorを過小評価しREADYを誤判定した。
- 詳細な必須観点を列挙しても、表面的なAC追加へ集中し、根本原因を見逃す場合がある。

## 6. 総括

Round 2プロンプトは独立性、出力整合性、Finding水増し抑制には有効だった。一方、同一モデル5組の平均改善は小さく、重大な限定語の読解や正本横断推論はプロンプトだけでは安定しなかった。

追加Claudeの2実行差は、同じモデルラベルでも結果が大きく変動することを示す。実務では、単発再実行や多数決ではなく、異種モデルの組合せと根本原因単位の審理が必要である。
