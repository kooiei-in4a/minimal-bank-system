# spec-review-002 LLMレビュー精度評価（16レビュー版）

## 1. 評価の位置づけ

本評価は、同一の仕様・正本・固定SHAを16件のLLM実行でレビューした単一課題のケーススタディである。一般性能ランキングではなく、この課題における独立レビュー性能を示す。

Round 1と同じ6軸・100点満点を使用した。

| 評価軸 | 配点 |
|---|---:|
| Finding Precision | 25 |
| Gold Finding Recall | 25 |
| 重大度・Verdict精度 | 15 |
| 根拠・トレーサビリティ | 15 |
| 修正案の妥当性 | 10 |
| Scope discipline | 10 |

## 2. 総合順位

| 順位 | モデル | 総合点 | Verdict | 特徴 |
|---:|---|---:|---|---|
| 1 | ChatGPT 5.6 Sol High | **95** | 正しい | 4件のMajorをすべて検出。重大度、修正方向、FAIL判定が最も安定。 |
| 2 | ChatGPT 5.6 Sol XHigh | **92** | 正しい | Major 4件をすべて検出し監査ログも補足。網羅性は最高水準だが一部過大評価。 |
| 3 | ChatGPT 5.6 Sol Middle | **91** | 正しい | 主要3論点に加え、0件履歴と監査・運用追跡を検出。収束性が高い。 |
| 4 | ChatGPT 5.6 Sol Fast | **90** | 正しい | AC、冪等性、利用者管理のMajor 3件へ正確に集中。高Precisionかつ簡潔。 |
| 5 | Gork 4.5 High Fast | **88** | 正しい | 冪等性、利用者管理、監査、§7.3まで広く検出。Round 1から大幅改善。 |
| 6 | ChatGPT 5.6 Luna XHigh | **86** | 正しい | F-003とF-004を高Precisionで検出。Finding水増しはないが、解約後参照と広いAC不足を見逃した。 |
| 7 | Claude Sonnet 5 High（browser） | **77** | 正しい | 振込同時実行AC、error code境界、§7.3矛盾を正確に検出しFAILへ到達。中核MajorのRecallは限定的。 |
| 8 | Kimi K3 | **76** | 正しい | AC不足をMajor化しVerdictを改善。解約後参照、利用者管理、error codeを見逃した。 |
| 9 | Composer 2.5 Fast | **73** | 不正確 | Secondary findingのPrecisionは良いが、MajorをMinorへ落としREADYと誤判定。 |
| 10 | GLM 5.2 High | **62** | 不正確 | 冪等性、Audit Log用語、§7.3を部分検出したが、主要問題の重大度判断が甘い。 |
| 11 | Claude Sonnet 5 High（通常） | **58** | 不正確 | 顧客更新AC不足は正しいが主要4論点を見逃し、READY判定は不適切。 |
| 12 | DeepSeek V4 Pro | **56** | 不正確 | 解約済み入出金AC不足を検出。Precisionは改善したがMajor Recallが低い。 |
| 13 | DeepSeek V4 Flash | **55** | 不正確 | 解約の既解約・不存在AC不足を検出したが主要契約をほぼ見逃した。 |
| 14 | Gemini 3.6 Flash | **54** | 結論のみ正しい | FAILには到達したが事実誤認と既知事項の重複Major化でPrecisionが低い。 |
| 15 | Gemini 3.6 Pro | **52** | 不正確 | 冪等キー保証期間だけを捉え、主要問題を見逃した。 |
| 16 | Gemini 3.6 Thinking | **51** | 不正確 | API設計寄りの改善へ偏り、Major RecallとVerdictが弱い。 |

## 3. 軸別評価

| モデル | Precision /25 | Recall /25 | Severity /15 | Evidence /15 | Fix /10 | Scope /10 | 合計 |
|---|---:|---:|---:|---:|---:|---:|---:|
| ChatGPT 5.6 Sol High | 24 | 24 | 14 | 15 | 9 | 9 | **95** |
| ChatGPT 5.6 Sol XHigh | 23 | 23 | 12 | 15 | 9 | 10 | **92** |
| ChatGPT 5.6 Sol Middle | 24 | 20 | 14 | 15 | 9 | 9 | **91** |
| ChatGPT 5.6 Sol Fast | 25 | 17 | 15 | 15 | 9 | 9 | **90** |
| Gork 4.5 High Fast | 23 | 21 | 13 | 14 | 9 | 8 | **88** |
| ChatGPT 5.6 Luna XHigh | 24 | 15 | 14 | 15 | 9 | 9 | **86** |
| Claude Sonnet 5 High（browser） | 22 | 10 | 13 | 15 | 9 | 8 | **77** |
| Kimi K3 | 21 | 14 | 12 | 14 | 8 | 7 | **76** |
| Composer 2.5 Fast | 22 | 15 | 7 | 13 | 8 | 8 | **73** |
| GLM 5.2 High | 20 | 10 | 6 | 11 | 7 | 8 | **62** |
| Claude Sonnet 5 High（通常） | 19 | 7 | 5 | 13 | 7 | 7 | **58** |
| DeepSeek V4 Pro | 23 | 4 | 4 | 11 | 6 | 8 | **56** |
| DeepSeek V4 Flash | 21 | 6 | 4 | 11 | 6 | 7 | **55** |
| Gemini 3.6 Flash | 15 | 9 | 7 | 12 | 6 | 5 | **54** |
| Gemini 3.6 Pro | 18 | 5 | 4 | 12 | 6 | 7 | **52** |
| Gemini 3.6 Thinking | 17 | 5 | 4 | 12 | 6 | 7 | **51** |

## 4. Verdict集計

- Goldどおりの`FAIL / NOT READY`へ、根拠・重大度を含めて到達: **8 / 16**
- `FAIL`という結論だけ一致し、主要根拠または重大度が不正確: **1 / 16**
- 誤って`READY FOR KOO APPROVAL`と判定: **7 / 16**

追加2件はいずれも正しい`FAIL / NOT READY`へ到達したため、正しいVerdict率は14件時点の6 / 14から8 / 16へ上昇した。

## 5. 追加モデル所見

### ChatGPT 5.6 Luna XHigh

**強み**

- 冪等性を単なるTTL不足へ縮小せず、D-13とD-17の衝突、失敗・競合・処理中到着、スコープ、要求同一性を根本原因単位で整理。
- 権限表に存在する管理機能を製品範囲として読み、仕様・AC・Out of scopeの欠落をMajor認定。
- 出力が短く、Finding重複がない。
- Verdict、Required fixes、Open approval itemsの整合が良い。

**弱み**

- B-01の「のみ」による解約後参照制限を見逃した。
- Issue #7が明示した広いAC・実質トレーサビリティ不足を独立Findingとして捉えなかった。
- error code、監査・障害ログ、0件履歴などのSecondary recallは低い。

**評価**

Sol FastよりRecallは低いが、冪等性と管理機能の2論点では高いPrecisionを示した。単独レビューより、ACに強いモデルとの組合せが適切。

### Claude Sonnet 5 High（browser）

**強み**

- 振込同時実行・解約競合という主要外部契約のAC不足を明確に検出。
- `解約済み`と`状態不整合`を409系・500系へ分ける必要を正しく指摘。
- §7.3と§22.1の決定主体・決定時期の矛盾を完全検出。
- Evidence整合性を暗号学的に再確認し、正しいFAILへ到達。

**弱み**

- 解約後参照、冪等性、利用者管理という中核3論点を見逃した。
- Gold全体のRecallは限定的。
- 通常実行と結論が大きく異なり、再現性が低い。

**評価**

単発の通常実行より大きく改善したが、同一ラベルでVerdictが反転しており、モデル能力だけでなく実行環境・サンプリング・コンテキスト処理の影響が大きい。

## 6. Claude Sonnet 5 Highの同一Round再現性

| 実行 | 点数 | Verdict | 主な検出 |
|---|---:|---|---|
| 通常実行 | 58 | PASS WITH FINDINGS / READY | 顧客更新AC、相手口座番号表示 |
| browser実行 | 77 | FAIL / NOT READY | 振込同時実行AC、F-005、F-009 |

- 点数差: **+19**
- Verdict: `READY`から`NOT READY`へ反転
- 共通して完全検出したMajor Gold: なし
- 両実行ともF-001、F-003、F-004を見逃した

同じモデルラベルでも単発結果の安定性は保証されない。再実行による多数決だけではなく、Findingを根本原因単位で統合する必要がある。

## 7. 推論レベル・モデル系列の所見

### ChatGPT 5.6系列

- Sol Highが最もバランス良好。
- Sol XHighはRecall最大だが過大評価がやや増える。
- Sol Fastは高Precisionの一次ゲートとして有効。
- Luna XHighは冪等性・製品範囲に強いが、横断ACと限定語のRecallはSol系より低い。

### Gemini 3.6系列

ThinkingがPro/Flashを明確に上回らず、推論モードを上げれば自動的に仕様レビューが改善するとはいえない。

### Claude Sonnet 5 High

2回の結果差が非常に大きい。実行環境やツール利用可否を固定しない比較では、モデル差と実行条件差を分離できない。

## 8. 実務上の推奨構成

### 精度を優先

1. Sol HighまたはSol XHighで全体レビュー。
2. Sol Fastで重複・過剰指摘を抑えた収束判定。
3. GorkまたはLuna XHighで冪等性・製品範囲を独立補完。
4. 人間または別AgentがF-001のような正本中の限定語を最終確認。

### コスト・速度を優先

1. Sol Fastで一次判定。
2. FAIL時または冪等性・権限範囲を含む場合だけSol High/XHighへ昇格。
3. Luna XHighは冪等性・管理機能の専門補完として利用。
4. Claudeは単発Ready判定に使わず、再実行または他モデル審理を必須とする。

## 9. 結論

- **最もバランスが良い:** ChatGPT 5.6 Sol High
- **最も網羅的:** ChatGPT 5.6 Sol XHigh
- **最も高Precisionで簡潔:** ChatGPT 5.6 Sol Fast
- **冪等性・製品範囲の専門補完:** Gork 4.5 High Fast / ChatGPT 5.6 Luna XHigh
- **追加2件のうち高評価:** ChatGPT 5.6 Luna XHigh
- **実行条件による変動が最大:** Claude Sonnet 5 High
- **単独Ready判定に不向き:** Composer、GLM、DeepSeek、Gemini 3.6各設定、Claude Sonnet 5 High
